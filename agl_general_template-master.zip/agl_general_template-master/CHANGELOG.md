## [1.2.3](https://github.com/khoa-allgrow/template-agl/compare/v1.2.2...v1.2.3) (2021-11-22)


### Bug Fixes

* **bs:** bugfix browser-sync ([29c0ec2](https://github.com/khoa-allgrow/template-agl/commit/29c0ec212607e278f74e118b1c49769bc722937d))
* **miss:** unmatched git version and npm version ([97bb17d](https://github.com/khoa-allgrow/template-agl/commit/97bb17db91b840c4f6fed0c1a6818f4a5820c5a1))



## [1.2.1](https://github.com/khoa-allgrow/template-agl/compare/v1.2.0...v1.2.1) (2021-10-28)


### Features

* **pnpm:** add pnpm ([a12b533](https://github.com/khoa-allgrow/template-agl/commit/a12b53357fa336740440908b1a383bab3159b027))



# [1.2.0](https://github.com/khoa-allgrow/template-agl/compare/v1.1.1...v1.2.0) (2021-10-01)


### Bug Fixes

* **win:** add cross-env ([3b9551b](https://github.com/khoa-allgrow/template-agl/commit/3b9551b67875f0d79f65484efebf70a002bf2119))



## [1.1.1](https://github.com/khoa-allgrow/template-agl/compare/v1.1.0...v1.1.1) (2021-09-29)


### Bug Fixes

* **windows:** windows os path bug fixed ([d1f4e5c](https://github.com/khoa-allgrow/template-agl/commit/d1f4e5cb382ba6b774d5ba11accf5c133a2776c2))



# [1.1.0](https://github.com/khoa-allgrow/template-agl/compare/v1.0.6...v1.1.0) (2021-09-29)



## [1.0.6](https://github.com/khoa-allgrow/template-agl/compare/v1.0.5...v1.0.6) (2021-09-24)


### Bug Fixes

* **log:** auto create changelog ([1c9e254](https://github.com/khoa-allgrow/template-agl/commit/1c9e254de551595f56c717740d16ed4fe51b1caa))



## [1.0.4](https://github.com/khoa-allgrow/template-agl/compare/v1.0.3...v1.0.4) (2021-09-15)


### Features

* **screenshot:** create screenshot-diff ([b79d90e](https://github.com/khoa-allgrow/template-agl/commit/b79d90e356d04883465da2c7e84464cfc5ef5dfe))



## [1.0.3](https://github.com/khoa-allgrow/template-agl/compare/v1.0.3-1...v1.0.3) (2021-09-15)


### Features

* **dev:** create quality validator module ([9c4dcb4](https://github.com/khoa-allgrow/template-agl/commit/9c4dcb45dcb87f75a55440c626511e838b36bbca))



## [1.0.3-1](https://github.com/khoa-allgrow/template-agl/compare/v1.0.3-0...v1.0.3-1) (2021-09-14)


### Bug Fixes

* **npm:** patch for git push error ([4c11041](https://github.com/khoa-allgrow/template-agl/commit/4c110411d73d052befab8c5c2b477d7a8acf1bce))



## [1.0.3-0](https://github.com/khoa-allgrow/template-agl/compare/v1.0.2...v1.0.3-0) (2021-09-14)


### Features

* **git:** test ([8859777](https://github.com/khoa-allgrow/template-agl/commit/8859777eaa8a494ccd6a9044e5b8354da7e09082))



## [1.0.2](https://github.com/khoa-allgrow/template-agl/compare/v1.0.2-0...v1.0.2) (2021-09-14)



## [1.0.2-0](https://github.com/khoa-allgrow/template-agl/compare/v1.0.1-0...v1.0.2-0) (2021-09-14)


### Bug Fixes

* **git:** edit npm-script ([bd083b9](https://github.com/khoa-allgrow/template-agl/commit/bd083b9bc51cc7b775c386f4d721d86c4165e4d6))


### Features

* **git:** create git process ([f0f4e0d](https://github.com/khoa-allgrow/template-agl/commit/f0f4e0d398df4f365424a29af041f75501f2c951))



