const justStr = (): string => new Date().toDateString();

const tsConsole = (val: string): void => {
    void console.log(`ts init: ${val}.`);
};

export const tsInit = (): void => {
    tsConsole(justStr());
}
