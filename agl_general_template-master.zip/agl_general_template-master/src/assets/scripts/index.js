import { jsInit } from '@/jsModule'
import { tsInit } from '@/tsModule'

window.addEventListener('DOMContentLoaded', () => {
    jsInit();
    tsInit();
}, false)
